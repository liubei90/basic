class InternalHandler():
    '''
    内部请求基类
    '''
    pass